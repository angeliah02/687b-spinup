using namespace vex;

class Chassis {
  public: 
  static void setVel(double LF, double LB, double RF, double RB);
  static void driveControl();
};